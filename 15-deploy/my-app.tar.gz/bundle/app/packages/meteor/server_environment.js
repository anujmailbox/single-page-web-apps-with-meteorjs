Meteor = {
  isClient: false,
  isServer: true
};
